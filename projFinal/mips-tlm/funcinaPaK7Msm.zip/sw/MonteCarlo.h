#include "game.h"

extern enum boardState Ai,Player;
