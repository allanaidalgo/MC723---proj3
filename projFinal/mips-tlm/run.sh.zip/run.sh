#!/usr/bin/sh
cd sw
make clean
make
cd ..
make run
