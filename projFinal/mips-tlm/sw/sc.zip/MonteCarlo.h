#include "game.h"

typedef struct node {
	gameState * state;
	float win, loses, draws;
}node;
extern enum boardState Ai,Player;
